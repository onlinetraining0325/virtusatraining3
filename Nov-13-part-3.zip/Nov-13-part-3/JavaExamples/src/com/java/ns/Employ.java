package com.java.ns;

public class Employ {


    private int empno;
    private String name;
    private double basic;

    public Employ[] showEmploy() {
       return null;
    }

    public String addEmploy(Employ employ) {
        return null;
    }
}
