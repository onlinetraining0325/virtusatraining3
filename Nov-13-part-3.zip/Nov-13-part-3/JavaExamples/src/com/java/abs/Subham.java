package com.java.abs;

public class Subham extends Training{
    @Override
    public void name() {
        System.out.println("Hi I am Subham...");
    }

    @Override
    public void email() {
        System.out.println("Email is subham@gmail.com");
    }
}
