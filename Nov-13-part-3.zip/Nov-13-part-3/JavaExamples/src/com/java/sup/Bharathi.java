package com.java.sup;

public class Bharathi extends Employ {
    public Bharathi(int empno, String name, double basic) {
        super(empno, name, basic);
    }
}
