package com.java.solid.isp;

public interface IAccountDetails {
    void pfDetails();
    void paySlips();
}
