package com.java.solid.isp;

public interface IEmployDetails {
    void name();
    void paymentDetails();
}
