package com.java.solid.isp;

public class IspSolution {
    public static void main(String[] args) {
        Karthik karthik = new Karthik();
        karthik.name();
        karthik.paymentDetails();
        karthik.paySlips();
        karthik.pfDetails();

        Prasanna prasanna = new Prasanna();
        prasanna.name();
        prasanna.paymentDetails();
    }
}
