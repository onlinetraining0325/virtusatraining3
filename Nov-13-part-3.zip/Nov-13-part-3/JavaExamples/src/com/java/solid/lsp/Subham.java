package com.java.solid.lsp;

public class Subham  extends Details{
    @Override
    void showInfo() {
        System.out.println("HiI am Subham...");
    }
}
