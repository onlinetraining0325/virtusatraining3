package com.java.ex;

public class NumerZeroException extends Exception {
    public NumerZeroException(String error) {
        super(error);
    }
}
