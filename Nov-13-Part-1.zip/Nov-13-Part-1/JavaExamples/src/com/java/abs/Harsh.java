package com.java.abs;

public class Harsh extends Training {

    @Override
    public void name() {
        System.out.println("Hi I am Harsh Naidu...");
    }

    @Override
    public void email() {
        System.out.println("Email is harsh@gmail.com...");
    }
}
