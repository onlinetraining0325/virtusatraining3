package com.java.spr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaEmployClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
