package com.java.virtusa.day1;

public class Demo {
    public static void main(String[] args) {
        Data data = new Data();
        data.sayHello();
        data.company();
    }
}
