package com.java.virtusa.day2;

public class Quiz6 {

    public static void main(String[] args) {
        String str = "Hello";
        str.concat(" World");
        System.out.println(str);
    }
}
