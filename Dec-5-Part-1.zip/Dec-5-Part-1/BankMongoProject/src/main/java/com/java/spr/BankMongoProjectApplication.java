package com.java.spr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankMongoProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankMongoProjectApplication.class, args);
    }

}
