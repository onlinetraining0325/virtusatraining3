package com.java.p2;

import com.java.p1.Data;

public class Hello {

    public void show() {
        Data data = new Data();
        System.out.println(data.publicStr);
    }
}
