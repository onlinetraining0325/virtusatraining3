package com.java.abs;

public class Lion extends Animal {

    @Override
    public void name() {
        System.out.println("Name is Lion...");
    }

    @Override
    public void type() {
        System.out.println("Its Wild Animal...");
    }
}
