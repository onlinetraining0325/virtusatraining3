package com.java.cols;

@FunctionalInterface
public interface StringProcessor {
    String process(String input);
}
