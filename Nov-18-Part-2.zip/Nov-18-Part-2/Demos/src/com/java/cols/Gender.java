package com.java.cols;

public enum Gender {
    MALE, FEMALE
}
