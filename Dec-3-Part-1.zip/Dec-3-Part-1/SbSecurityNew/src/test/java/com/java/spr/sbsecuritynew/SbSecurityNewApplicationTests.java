package com.java.spr.sbsecuritynew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbSecurityNewApplicationTests {

    @Test
    void contextLoads() {
    }

}
