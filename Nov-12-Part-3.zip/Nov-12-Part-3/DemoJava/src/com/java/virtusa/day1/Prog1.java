package com.java.virtusa.day1;

public class Prog1 {
    public static void main(String[] args) {
        int x = 12;
        double y = 12.5;
        String name = "Chandra";
        boolean flag = true;
        System.out.println("X value " +x);
        System.out.println("Y value " +y);
        System.out.println("Name value " +name);
        System.out.println("Flag value " +flag);
    }
}
