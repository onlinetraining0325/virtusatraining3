package com.java.virtusa.day2;

public class Quiz1 {
    public static void main(String[] args) {
        System.out.println("5" +3+8);
        System.out.println("5" +(3+8));
        System.out.println("5 + 3" +8);
    }
}
