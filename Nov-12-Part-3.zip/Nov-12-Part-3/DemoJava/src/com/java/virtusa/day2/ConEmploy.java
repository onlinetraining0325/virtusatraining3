package com.java.virtusa.day2;

public class ConEmploy {

    public static void main(String[] args) {
        Employ e1 = new Employ(1, "Lokesh",82344);
        Employ e2 = new Employ(2, "Shalli",87331);

        System.out.println(e1);
        System.out.println(e2);
    }
}
