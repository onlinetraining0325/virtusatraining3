package com.java.employ.model;

public enum Gender {
    MALE, FEMALE
}
