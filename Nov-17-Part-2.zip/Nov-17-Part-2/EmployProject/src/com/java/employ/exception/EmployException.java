package com.java.employ.exception;

public class EmployException extends Exception {
    public EmployException() {
    }
    public EmployException(String message) {
        super(message);
    }
}
