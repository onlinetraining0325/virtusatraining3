package com.java.virtusa.model;

public enum Gender {
  MALE, FEMALE
}
