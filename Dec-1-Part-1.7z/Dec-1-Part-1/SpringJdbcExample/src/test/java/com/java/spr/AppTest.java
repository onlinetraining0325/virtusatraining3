package com.java.spr;

import org.junit.Test;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
